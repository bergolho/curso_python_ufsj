
# Funcao principal em Python
def main ():

	# Usando programacao funcional com 'lambda' 
	g = lambda x: x**2
	print g(8)

if __name__ == "__main__":
	main()	

import numpy as np

notas = np.array([ 6., 7.5, 8., 9.2, 4.3 ])

print notas.mean()

print notas.max()

print notas.min()
